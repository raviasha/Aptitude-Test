These two ZIPs contain textbook page images only, NOT importable question banks. Do not upload them to Coordinator. Question extraction and verification are still required.
